class Pilha:

    def __init__(self, tamanho):
        self._dados = [0]*tamanho
        self._topo = 0

    def empty(self):
        return self._topo == 0

    def push(self, valor):
        self._dados[self._topo] = valor
        self._topo += 1

    def peek(self):
        if self.empty():
            raise StackUnderflow()
        return self._dados[self._topo-1]

"""Feature: criar uma pilha com tamanho estático."""

"""Criar feature para uso em behave


Cenario: crio uma pilha.
Dado o tamanho da pilha sendo 10
Quando crio uma pilha
Entao tenho uma pilha com 10 de capacidade"""


class StackUnderflow(Exception):
    """Define classe para acesso de pilha vazia"""
    pass
